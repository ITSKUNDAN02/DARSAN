import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

class _PlaceSuggestion {
  final String label;
  final LatLng point;

  const _PlaceSuggestion({required this.label, required this.point});
}

class MapScreen extends StatefulWidget {
  final String? destinationQuery;
  final bool autoStartNavigation;

  const MapScreen({
    super.key,
    this.destinationQuery,
    this.autoStartNavigation = false,
  });

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  LatLng? currentLocation;
  LatLng? startPoint;
  LatLng? endPoint;
  List<LatLng> routePoints = [];

  final MapController mapController = MapController();
  StreamSubscription<Position>? _positionStream;

  bool _isNavigating = false;

  _PlaceSuggestion? _fromSelection;
  _PlaceSuggestion? _toSelection;

  final TextEditingController fromController = TextEditingController();
  final TextEditingController toController = TextEditingController();

  final String apiKey = "YOUR_ORS_API_KEY";

  @override
  void initState() {
    super.initState();
    _bootstrapMap();
  }

  Future<void> _bootstrapMap() async {
    await getLocation();
    _startLocationTracking();

    if (widget.destinationQuery != null &&
        widget.destinationQuery!.isNotEmpty) {
      toController.text = widget.destinationQuery!;
      await fetchRouteToDestination(widget.destinationQuery!);
    }
  }

  Future<void> getLocation() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      currentLocation = LatLng(position.latitude, position.longitude);
    });
  }

  void _startLocationTracking() {
    _positionStream =
        Geolocator.getPositionStream(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 10,
          ),
        ).listen((Position pos) {
          setState(() {
            currentLocation = LatLng(pos.latitude, pos.longitude);
          });

          if (_isNavigating) {
            mapController.move(currentLocation!, 16);
          }
        });
  }

  Future<List<_PlaceSuggestion>> _suggestionsFor(String query) async {
    if (query.isEmpty) return [];

    final url =
        "https://api.openrouteservice.org/geocode/search?api_key=$apiKey&text=${Uri.encodeComponent(query)}&size=5";

    final response = await http.get(Uri.parse(url));
    if (response.statusCode != 200) return [];

    final data = jsonDecode(response.body);
    final features = data["features"] as List;

    return features.map((f) {
      final coords = f["geometry"]["coordinates"];
      final props = f["properties"];

      return _PlaceSuggestion(
        label: props["label"] ?? "Unknown",
        point: LatLng(coords[1], coords[0]),
      );
    }).toList();
  }

  Future<void> fetchRoute() async {
    if (startPoint == null || endPoint == null) return;

    final url =
        "https://api.openrouteservice.org/v2/directions/driving-car?api_key=$apiKey&start=${startPoint!.longitude},${startPoint!.latitude}&end=${endPoint!.longitude},${endPoint!.latitude}";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final coords = data["features"][0]["geometry"]["coordinates"];

      setState(() {
        routePoints = coords.map<LatLng>((c) => LatLng(c[1], c[0])).toList();
      });
    }
  }

  Future<LatLng?> geocode(String text) async {
    final url =
        "https://api.openrouteservice.org/geocode/search?api_key=$apiKey&text=${Uri.encodeComponent(text)}";

    final res = await http.get(Uri.parse(url));
    if (res.statusCode != 200) return null;

    final data = jsonDecode(res.body);
    final coords = data["features"][0]["geometry"]["coordinates"];

    return LatLng(coords[1], coords[0]);
  }

  Future<void> fetchRouteFromText() async {
    final from = _fromSelection?.point ?? await geocode(fromController.text);
    final to = _toSelection?.point ?? await geocode(toController.text);

    if (from == null || to == null) return;

    setState(() {
      startPoint = from;
      endPoint = to;
    });

    await fetchRoute();
  }

  Future<void> fetchRouteToDestination(String text) async {
    final dest = await geocode(text);
    if (dest == null) return;

    setState(() {
      startPoint = currentLocation;
      endPoint = dest;
    });

    await fetchRoute();
  }

  void _swap() {
    final temp = fromController.text;
    fromController.text = toController.text;
    toController.text = temp;

    final tempSel = _fromSelection;
    _fromSelection = _toSelection;
    _toSelection = tempSel;
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    fromController.dispose();
    toController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final center = currentLocation ?? const LatLng(27.7172, 85.3240);

    return Scaffold(
      appBar: AppBar(title: const Text("Map")),
      body: Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            options: MapOptions(initialCenter: center, initialZoom: 15),
            children: [
              TileLayer(
                urlTemplate:
                    "https://tile.openstreetmap.fr/hot/{z}/{x}/{y}.png",
                subdomains: const ['a', 'b', 'c'],
                userAgentPackageName: 'com.example.darsan_app',
                tileProvider: NetworkTileProvider(),
              ),
              if (routePoints.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: routePoints,
                      strokeWidth: 4,
                      color: Colors.blue,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  if (currentLocation != null)
                    Marker(
                      point: currentLocation!,
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.my_location, color: Colors.red),
                    ),
                ],
              ),
            ],
          ),

          // UI
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: TypeAheadField<_PlaceSuggestion>(
                                suggestionsCallback: _suggestionsFor,
                                builder: (context, controller, focusNode) {
                                  return TextField(
                                    controller: fromController,
                                    focusNode: focusNode,
                                    decoration: const InputDecoration(
                                      hintText: "From",
                                    ),
                                  );
                                },
                                itemBuilder: (context, s) =>
                                    ListTile(title: Text(s.label)),
                                onSelected: (s) {
                                  setState(() {
                                    _fromSelection = s;
                                    fromController.text = s.label;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),

                        Row(
                          children: [
                            Expanded(
                              child: TypeAheadField<_PlaceSuggestion>(
                                suggestionsCallback: _suggestionsFor,
                                builder: (context, controller, focusNode) {
                                  return TextField(
                                    controller: toController,
                                    focusNode: focusNode,
                                    decoration: const InputDecoration(
                                      hintText: "To",
                                    ),
                                  );
                                },
                                itemBuilder: (context, s) =>
                                    ListTile(title: Text(s.label)),
                                onSelected: (s) {
                                  setState(() {
                                    _toSelection = s;
                                    toController.text = s.label;
                                  });
                                },
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.swap_vert),
                              onPressed: _swap,
                            ),
                          ],
                        ),

                        ElevatedButton(
                          onPressed: fetchRouteFromText,
                          child: const Text("Get Route"),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
